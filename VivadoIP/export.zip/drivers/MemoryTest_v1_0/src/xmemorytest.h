// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XMEMORYTEST_H
#define XMEMORYTEST_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmemorytest_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XMemorytest_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XMemorytest;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMemorytest_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMemorytest_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMemorytest_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMemorytest_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XMemorytest_Initialize(XMemorytest *InstancePtr, u16 DeviceId);
XMemorytest_Config* XMemorytest_LookupConfig(u16 DeviceId);
int XMemorytest_CfgInitialize(XMemorytest *InstancePtr, XMemorytest_Config *ConfigPtr);
#else
int XMemorytest_Initialize(XMemorytest *InstancePtr, const char* InstanceName);
int XMemorytest_Release(XMemorytest *InstancePtr);
#endif

void XMemorytest_Start(XMemorytest *InstancePtr);
u32 XMemorytest_IsDone(XMemorytest *InstancePtr);
u32 XMemorytest_IsIdle(XMemorytest *InstancePtr);
u32 XMemorytest_IsReady(XMemorytest *InstancePtr);
void XMemorytest_EnableAutoRestart(XMemorytest *InstancePtr);
void XMemorytest_DisableAutoRestart(XMemorytest *InstancePtr);

void XMemorytest_Set_a(XMemorytest *InstancePtr, u32 Data);
u32 XMemorytest_Get_a(XMemorytest *InstancePtr);

void XMemorytest_InterruptGlobalEnable(XMemorytest *InstancePtr);
void XMemorytest_InterruptGlobalDisable(XMemorytest *InstancePtr);
void XMemorytest_InterruptEnable(XMemorytest *InstancePtr, u32 Mask);
void XMemorytest_InterruptDisable(XMemorytest *InstancePtr, u32 Mask);
void XMemorytest_InterruptClear(XMemorytest *InstancePtr, u32 Mask);
u32 XMemorytest_InterruptGetEnabled(XMemorytest *InstancePtr);
u32 XMemorytest_InterruptGetStatus(XMemorytest *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
